from .conversor import letra_para_numero
